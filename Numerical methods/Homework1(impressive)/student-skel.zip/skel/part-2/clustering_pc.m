function [centroids] = clustering_pc(points, NC)
endfunction
