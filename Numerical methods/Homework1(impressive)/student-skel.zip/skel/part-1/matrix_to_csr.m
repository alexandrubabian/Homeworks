function [values, colind, rowptr] = matrix_to_csr(A)
endfunction