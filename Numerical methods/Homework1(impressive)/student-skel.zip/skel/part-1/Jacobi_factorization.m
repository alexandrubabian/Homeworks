function [G_J, c_J] = Jacobi_factorization(A, b)
endfunction
