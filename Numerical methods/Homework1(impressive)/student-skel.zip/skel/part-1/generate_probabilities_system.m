function [A, b] = generate_probabilities_system(rows)
endfunction