function [sol] = hsvHistogram(path_to_image, count_bins)
end