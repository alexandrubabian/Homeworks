function [w] = learn(X, y)
end
